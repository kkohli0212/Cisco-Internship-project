from django.urls import path
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    # Home Url
    path('', views.home, name='home'),

    # Register URL
    path('register/', views.register, name='register'),

    # Profile URL
    path('profile/', views.profile, name='profile'),

    # Log-out URL
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Change Password URL
    path('change_password/', views.change_password, name='change_password'),

    # Change profile picture URL
    path('change_profile_pic/', views.change_profile_pic, name='change_profile_pic'),

    # Page 2 URL
    path('page2/', views.page2, name='page2'),


]
