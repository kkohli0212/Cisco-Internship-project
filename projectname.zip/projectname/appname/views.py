from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render, redirect
from .forms import UserRegistrationForm, UserProfileForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .models import UserProfile
from django.contrib import messages
from django.contrib.auth.models import User

def home(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('profile')
    else:
        form = AuthenticationForm()

    return render(request, 'registration/home.html', {'form': form})


def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        profile_form = UserProfileForm(request.POST, request.FILES)
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user.password)
            user.save()
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()
            return redirect('home')
    else:
        user_form = UserRegistrationForm()
        profile_form = UserProfileForm()

    return render(request, 'registration/register.html', {'user_form': user_form, 'profile_form': profile_form})


@login_required
def profile(request):

    if not request.user.is_authenticated:
        return HttpResponse("NOT AUTHORIZED")
    
    user_profile=UserProfile.objects.get(user=request.user)

    return render(request, 'registration/profile.html',{'user_profile': user_profile})


@login_required
def change_password(request):
    user = request.user

    if request.method == "POST":
        # Get new password and confirmation
        password = request.POST["password"]
        new_password = request.POST["new_password"]
        conform_new_password = request.POST["conform_new_password"]

        # Verify the user's current password
        user = authenticate(request, username=user.username, password=password)
        if user is None:
            messages.error(request, "The current password is incorrect.")
            return redirect(f"/change_password/")
        
        # Password validation checks.
        if new_password != conform_new_password:
            messages.error(request, "Passwords didn't match. Please try again.")
            return redirect(f"/change_password/")
        if len(new_password) < 4:
            messages.error(request, "Password must contain at least 4 characters.")
            return redirect(f"/change_password/")

        # Change the user's password.
        user.set_password(new_password)
        user.save()

        messages.success(request, "Password has changed successfully!")
        return redirect(f"/profile/")
        
    return render(request, "registration/change_password.html") 


@login_required
def change_profile_pic(request):
    user = request.user
    if request.method == "POST":
        profile = UserProfile.objects.get(user=user)

        password = request.POST['password']

        # Verify the user's current password.
        verify = authenticate(request, username=user.username, password=password)
        if verify is None:
            messages.error(request, "The current password is incorrect.")
            return redirect(f"/change_profile_pic/")

        profile_form = UserProfileForm(request.POST, request.FILES, instance=profile)

        if profile_form.is_valid():
            profile_form.save()
            messages.success(request, "Profile Picture has changed successfully!")

        return redirect(f"/profile/")


    context = {
        'user_profile_form': UserProfileForm,
    }    

    return render(request, "registration/change_profile_pic.html", context)

@login_required
def page2(request):

    context = {
        # ...
    }

    return render(request, "registration/page2.html", context)
    