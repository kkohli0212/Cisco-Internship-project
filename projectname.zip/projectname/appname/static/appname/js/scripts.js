document.addEventListener("DOMContentLoaded", function () {
    // Existing logic for the "Register" link
    const registerLink = document.querySelector("#register-link");
    registerLink.addEventListener("click", function (event) {
        event.preventDefault();
        alert("You clicked the Register link!");
    });
    
    // Toggle dropdown function
    window.toggleDropdown = function() {
        const dropdownContent = document.getElementById("dropdown-content");
        if (dropdownContent.style.display === "none") {
            dropdownContent.style.display = "block";
        } else {
            dropdownContent.style.display = "none";
        }
    }
});
